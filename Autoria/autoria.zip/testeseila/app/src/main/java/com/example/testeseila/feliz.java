package com.example.testeseila;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class feliz extends AppCompatActivity {
    static ArrayList<user> contas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feliz);
        getSupportActionBar().hide();
    }
}