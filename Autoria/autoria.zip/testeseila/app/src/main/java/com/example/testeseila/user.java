package com.example.testeseila;

public class user {
    String pessoa;
    String senhola;
    Boolean adm;

    public user(String pessoa, String senhola, Boolean adm){
        this.pessoa = pessoa;
        this.senhola = senhola;
        this.adm = adm;
    }

    public String getPessoa() {
        return pessoa;
    }

    public void setPessoa(String pessoa) {
        this.pessoa = pessoa;
    }

    public String getSenhola() {
        return senhola;
    }

    public void setSenhola(String senhola) {
        this.senhola = senhola;
    }

    public Boolean getAdm() {
        return adm;
    }

    public void setAdm(Boolean adm) {
        this.adm = adm;
    }
}

