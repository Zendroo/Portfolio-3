package com.example.testeseila;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText pessoa, senhola;
    ArrayList<user> felizao = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        pessoa = findViewById(R.id.nome1);
        senhola = findViewById(R.id.senha);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        addusuario();
    }

    private void addusuario() {
        user u1 = new user("pessoa", "legal", true);
        felizao.add(u1);
    }

    public void felizar(View v) {
        String user = pessoa.getText().toString();
        String pass = senhola.getText().toString();
        String mensagem = "Opa";
        for (user a : felizao) {
            if (user.equals(a.getPessoa()) && pass.equals(a.getSenhola())) {
                if (a.adm) {
                    Intent A = new Intent(this, feliz.class);
                    startActivity(A);
                } else {
                    Intent i = new Intent(this, raiva.class);
                    startActivity(i);
                }
                mensagem = "Bem-vindo";
                break;
            }
            else {
                mensagem = "Nem deu!";
            }
            Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();
        }
    }
}

