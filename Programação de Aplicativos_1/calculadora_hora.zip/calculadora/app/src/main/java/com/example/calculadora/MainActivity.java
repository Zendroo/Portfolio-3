package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    EditText hora1, hora2, min1, min2;
    TextView mostraHora, mostraMin;
    int h1, m1, h2, m2, horaTotal, minTotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        hora1 = findViewById(R.id.hora1);
        min1 = findViewById(R.id.min1);
        hora2 = findViewById(R.id.hora2);
        min2 = findViewById(R.id.min2);
        mostraHora = findViewById(R.id.mostraHora);
        mostraMin = findViewById(R.id.mostraMin);
    }

    public void recebeHora(){
        h1 = Integer.parseInt(hora1.getText().toString());
        m1 = Integer.parseInt(min1.getText().toString());
        h2 = Integer.parseInt(hora2.getText().toString());
        m2 = Integer.parseInt(min2.getText().toString());

        while(m1 > 59){
            h1 ++;
            m1 = m1 - 60;
        }
        while(m2 >59){
            h2 ++;
            m2 = m2 -60;
        }
    }

    public void btnSub(View view){
        recebeHora();
        if(h2 > h1){
            horaTotal = h2 - h1;
            minTotal = m2 - m1;
        }
        else {
            horaTotal = h1 - h2;
            if (m2 > m1) {
                m1 = m1 +60;
                horaTotal = h1 -1;
                minTotal = m1 - m2;

            } else {
                minTotal = m1 - m2;
            }
        }
        while(minTotal < 0){
            horaTotal --;
            minTotal = minTotal +60;
        }

        mostraHora.setText(horaTotal+"");
        mostraMin.setText(minTotal+"");
    }

    public void btnSoma(View view){
        recebeHora();
        horaTotal = h1 + h2;
        minTotal = m1 +m2;
        while(minTotal >59){
            horaTotal ++;
            minTotal = minTotal -60;
        }
        mostraHora.setText(horaTotal+"");
        mostraMin.setText(minTotal+"");
    }

    public void btnReset(View view){
        mostraHora.setText("");
        mostraMin.setText("");
        hora1.setText("");
        hora2.setText("");
        min1.setText("");
        min2.setText("");
    }
}